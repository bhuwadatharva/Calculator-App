package com.example.myfirstapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void Add(View v){
        EditText et1 =(EditText)findViewById(R.id.number1);
        EditText et2 =(EditText)findViewById(R.id.number2);
        TextView tv1 = (TextView)findViewById(R.id.answer);

        int n1 = Integer.parseInt(et1.getText().toString());
        int n2 = Integer.parseInt(et2.getText().toString());
        int answer = n1+n2;

        tv1.setText("Total value"+ answer);
    }

    public void Subtract(View v){
        EditText et1 =(EditText)findViewById(R.id.number1);
        EditText et2 =(EditText)findViewById(R.id.number2);
        TextView tv1 = (TextView)findViewById(R.id.answer);

        int n1 = Integer.parseInt(et1.getText().toString());
        int n2 = Integer.parseInt(et2.getText().toString());
        int answer = n1-n2;

        tv1.setText("Total value"+ answer);
    }

    public void Multiply(View v){
        EditText et1 =(EditText)findViewById(R.id.number1);
        EditText et2 =(EditText)findViewById(R.id.number2);
        TextView tv1 = (TextView)findViewById(R.id.answer);

        int n1 = Integer.parseInt(et1.getText().toString());
        int n2 = Integer.parseInt(et2.getText().toString());
        int answer = n1*n2;

        tv1.setText("Total value"+ answer);
    }

    public void Division(View v){
        EditText et1 =(EditText)findViewById(R.id.number1);
        EditText et2 =(EditText)findViewById(R.id.number2);
        TextView tv1 = (TextView)findViewById(R.id.answer);

        int n1 = Integer.parseInt(et1.getText().toString());
        int n2 = Integer.parseInt(et2.getText().toString());
        int answer = n1/n2;

        tv1.setText("Total value"+ answer);
    }
}

